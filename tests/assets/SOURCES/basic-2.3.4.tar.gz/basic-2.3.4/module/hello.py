def hello(name):
    return "Hello {}!".format(name)
